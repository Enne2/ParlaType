# ParlaType Core Module
